import { useFormik } from "formik";
import React, { useState, useCallback } from "react";
import InputTypes from "./InputTypes";
import InputAddress from "./InputAddress";
import useFormInput from "./useFormInput";

export default function YoutubeForm() {
  //   const [name, setName] = useState("");
  const name = useFormInput("");
  const [address, setAddress] = useState("");

  const test = (e) => {
    console.log(name.setVal);
    e.preventDefault();
    console.log("name", name);
    name.setVal("IT will work");
  };

  return (
    <div>
      <form>
        {console.log("parent render")}
        <InputTypes connector={name} />
        <InputAddress
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        />
        <button onClick={(e) => test(e)}>test</button>

        {/* <div className="form-control">
          <label htmlFor="email">E-mail</label>
          <input
            type="email"
            id="email"
            name="email"
            onChange={formik.handleChange}
            value={formik.values.email}
          />
        </div> */}

        {/* <div className="form-control">
          <label htmlFor="channel">Channel</label>
          <input
            type="text"
            id="channel"
            name="channel"
            onChange={formik.handleChange}
            value={formik.values.channel}
          />
        </div> */}

        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
