import logo from "./logo.svg";
import "./App.css";
import YoutubeForm from "./components/YoutubeForm";

function App() {
  return (
    <div className="App">
      <YoutubeForm />
    </div>
  );
}

export default App;
